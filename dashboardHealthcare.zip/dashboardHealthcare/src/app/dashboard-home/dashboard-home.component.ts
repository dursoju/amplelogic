import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-dashboard-home',
  templateUrl: './dashboard-home.component.html',
  styleUrls: ['./dashboard-home.component.scss']
})
export class DashboardHomeComponent implements OnInit {
  sidebarVisible2 = false;
  responsiveOptions;
  basicData: any;

  multiAxisData: any;

  multiAxisOptions: any;

  lineStylesData: any;

  basicOptions: any;


  hospitalData = [
    {
      id: '1',
      hospitalName: 'Archana Hospitals',
      addrss: 'Somajiguda Hyderbad ',
      phone: '+91 9876543210',
      image: '../../assets/images/hospital.jpg',
    },
    {
      id: '2',
      hospitalName: 'Zoi Hospitals',
      addrss: 'Somajiguda Hyderbad ',
      phone: '+91 9876543210',
      image: '../../assets/images/hospital.jpg',
    },
    {
      id: '3',
      hospitalName: 'Aster Prime Hospitals',
      addrss: 'Kondapur, Hyderabad',
      phone: '+91 9876543210',
      image: '../../assets/images/hospital.jpg',
    }
    ,
    {
      id: '4',
      hospitalName: 'Sri Holistic Hospitals',
      addrss: 'KPHB Colony, Hyderabad ',
      phone: '+91 9876543210',
      image: '../../assets/images/hospital.jpg',
    }
    ,
    {
      id: '5',
      hospitalName: 'Germanten Hospitalss',
      addrss: 'Attapur, Hyderabad',
      phone: '+91 9876543210',
      image: '../../assets/images/hospital.jpg',
    }
  ]

  products = [
    {
      name: 'Leslie Alexander',
      email: 'alexander@example.com',
      date: '11/07/2024',
      time: '09:15 - 12:00',
      doctor:'Dr. Jacob Jones',
      conditions: 'Mumps Stage II',
      image: '../../assets/images/a1.png',
    },
    {
      name: 'Ronald Richards',
      email: 'ronald.richards@example.com',
      date: '11/07/2024',
      time: '09:15 - 12:00',
      doctor:'Dr. Jacob Jones',
      conditions: 'Mumps Stage II',
      image: '../../assets/images/a2.png',
    },
    {
      name: 'Jane Cooper',
      email: 'jane.cooper@example.com',
      date: '11/07/2024',
      time: '09:15 - 12:00',
      doctor:'Dr. Jacob Jones',
      conditions: 'Mumps Stage II',
      image: '../../assets/images/a3.png',
    },
    {
      name: 'Robert Fox',
      email: 'robert.fox@gmail.com',
      date: '11/07/2024',
      time: '09:15 - 12:00',
      doctor:'Dr. Jacob Jones',
      conditions: 'Mumps Stage II',
      image: '../../assets/images/a4.png',
    },
    {
      name: 'Jenny Wilson',
      email: 'jenny.wilson@example.com',
      date: '11/07/2024',
      time: '09:15 - 12:00',
      doctor:'Dr. Jacob Jones',
      conditions: 'Mumps Stage II',
      image: '../../assets/images/a2.png',

    }
  ]

  constructor() {

    this.basicOptions = {
      plugins: {
          legend: {
              labels: {
                  color: '#495057'
              }
          }
      },
      scales: {
          x: {
              ticks: {
                  color: '#495057'
              },
              grid: {
                  color: '#ebedef'
              }
          },
          y: {
              ticks: {
                  color: '#495057'
              },
              grid: {
                  color: '#ebedef'
              }
          }
      }
  };

  this.lineStylesData = {
    labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
    datasets: [
        {
            label: 'First Dataset',
            data: [65, 59, 80, 81, 56, 55, 40],
            fill: false,
            tension: .4,
            borderColor: '#42A5F5'
        },
        {
            label: 'Second Dataset',
            data: [28, 48, 40, 19, 86, 27, 90],
            fill: false,
            borderDash: [5, 5],
            tension: .4,
            borderColor: '#66BB6A'
        },
        {
            label: 'Third Dataset',
            data: [12, 51, 62, 33, 21, 62, 45],
            fill: true,
            borderColor: '#FFA726',
            tension: .4,
            backgroundColor: 'rgba(255,167,38,0.2)'
        }
    ]
};


    this.responsiveOptions = [
      {
          breakpoint: '1920px',
          numVisible: 3,
          numScroll: 3
      },
      {
          breakpoint: '1200px',
          numVisible: 2,
          numScroll: 2
      },
      {
          breakpoint: '680px',
          numVisible: 1,
          numScroll: 1
      }
  ];
   }

  ngOnInit(): void {
  }

}
